const { Pool } = require("pg");

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

pool.on("error", (err) => {
  console.error("[db] unexpected pool error:", err.message);
});

module.exports = { pool, query: (text, params) => pool.query(text, params) };
