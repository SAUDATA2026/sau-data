-- SauriData schema (PostgreSQL)

CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  full_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer', 'admin')),
  wallet_balance_kobo BIGINT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS networks (
  id SERIAL PRIMARY KEY,
  name TEXT UNIQUE NOT NULL      -- MTN, Glo, Airtel, 9mobile
);

CREATE TABLE IF NOT EXISTS data_plans (
  id SERIAL PRIMARY KEY,
  network_id INTEGER NOT NULL REFERENCES networks(id),
  name TEXT NOT NULL,             -- e.g. "1GB - 30 Days"
  size_mb INTEGER NOT NULL,
  validity_days INTEGER NOT NULL,
  price_kobo BIGINT NOT NULL,     -- what the customer pays
  cost_kobo BIGINT NOT NULL,      -- what it costs you from the VTU provider
  provider_plan_code TEXT,        -- the code the VTU provider expects
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS transactions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  type TEXT NOT NULL CHECK (type IN ('fund', 'purchase', 'refund', 'admin_adjustment')),
  amount_kobo BIGINT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'success', 'failed')),
  plan_id INTEGER REFERENCES data_plans(id),
  recipient_phone TEXT,
  reference TEXT UNIQUE,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS wallet_fundings (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  amount_kobo BIGINT NOT NULL,
  paystack_reference TEXT UNIQUE NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'success', 'failed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO networks (name) VALUES ('MTN'), ('Glo'), ('Airtel'), ('9mobile')
  ON CONFLICT (name) DO NOTHING;

-- Sample starter plans (edit prices freely from the admin dashboard later)
INSERT INTO data_plans (network_id, name, size_mb, validity_days, price_kobo, cost_kobo, active)
SELECT n.id, plan.name, plan.size_mb, plan.validity_days, plan.price_kobo, plan.cost_kobo, true
FROM networks n
JOIN (VALUES
  ('MTN', '500MB - 30 Days', 500, 30, 30000, 25000),
  ('MTN', '1GB - 30 Days', 1000, 30, 55000, 48000),
  ('MTN', '2GB - 30 Days', 2000, 30, 100000, 90000),
  ('Glo', '1GB - 30 Days', 1000, 30, 50000, 43000),
  ('Glo', '2GB - 30 Days', 2000, 30, 95000, 85000),
  ('Airtel', '1GB - 30 Days', 1000, 30, 52000, 45000),
  ('Airtel', '2GB - 30 Days', 2000, 30, 98000, 88000),
  ('9mobile', '1GB - 30 Days', 1000, 30, 48000, 41000)
) AS plan(network_name, name, size_mb, validity_days, price_kobo, cost_kobo)
  ON plan.network_name = n.name
ON CONFLICT DO NOTHING;
