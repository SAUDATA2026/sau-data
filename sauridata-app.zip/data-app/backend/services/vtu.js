/**
 * VTU (Virtual Top-Up) provider adapter — actually delivers data onto a phone
 * number. Every real provider (VTpass, Clubkonnect, Reloadly, a direct telco
 * API, etc.) has a different request/response shape, so this file is the
 * single place that knows about that. The rest of the app only calls
 * `deliverData(...)` and never touches provider specifics.
 *
 * Set VTU_PROVIDER=mock in .env for development — it always succeeds after a
 * short simulated delay, so you can build/test the full purchase flow before
 * you have live provider credentials.
 */

const fetch = require("node-fetch");

async function deliverData({ networkName, providerPlanCode, phoneNumber }) {
  const provider = process.env.VTU_PROVIDER || "mock";

  if (provider === "mock") {
    await new Promise((r) => setTimeout(r, 400));
    return {
      success: true,
      providerReference: `mock_${Date.now()}`,
      message: `Mock delivery: ${networkName} data sent to ${phoneNumber}`
    };
  }

  // --- Example shape for a real provider (VTpass-style). Adjust to match
  // whichever provider you actually integrate. ---
  try {
    const res = await fetch(`${process.env.VTU_BASE_URL}/data`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.VTU_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        network: networkName,
        variation_code: providerPlanCode,
        phone: phoneNumber,
        request_id: `sd_${Date.now()}`
      })
    });
    const data = await res.json();

    if (!res.ok || data.status !== "success") {
      return { success: false, providerReference: null, message: data.message || "Provider declined the request." };
    }
    return { success: true, providerReference: data.reference || data.request_id, message: "Delivered" };
  } catch (err) {
    return { success: false, providerReference: null, message: err.message };
  }
}

module.exports = { deliverData };
