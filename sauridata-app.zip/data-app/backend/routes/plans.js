const express = require("express");
const { query } = require("../db");

const router = express.Router();

// GET /api/plans — list active plans grouped by network
router.get("/", async (req, res) => {
  try {
    const result = await query(
      `SELECT dp.id, dp.name, dp.size_mb, dp.validity_days, dp.price_kobo, n.name AS network
       FROM data_plans dp
       JOIN networks n ON n.id = dp.network_id
       WHERE dp.active = true
       ORDER BY n.name, dp.price_kobo`
    );

    const grouped = {};
    for (const row of result.rows) {
      grouped[row.network] = grouped[row.network] || [];
      grouped[row.network].push(row);
    }
    res.json({ plans: grouped });
  } catch (err) {
    console.error("[plans] list error:", err.message);
    res.status(500).json({ error: "Could not load data plans." });
  }
});

module.exports = router;
