const express = require("express");
const { query } = require("../db");
const { requireAuth } = require("../middleware/authMiddleware");
const { deliverData } = require("../services/vtu");

const router = express.Router();

// POST /api/purchase  { planId, phoneNumber }
router.post("/", requireAuth, async (req, res) => {
  const { planId, phoneNumber } = req.body || {};
  if (!planId || !phoneNumber) {
    return res.status(400).json({ error: "planId and phoneNumber are required." });
  }
  if (!/^0\d{10}$/.test(phoneNumber)) {
    return res.status(400).json({ error: "Enter a valid 11-digit phone number (e.g. 08012345678)." });
  }

  const client = await require("../db").pool.connect();
  try {
    await client.query("BEGIN");

    const planResult = await client.query(
      `SELECT dp.id, dp.name, dp.price_kobo, dp.provider_plan_code, n.name AS network
       FROM data_plans dp JOIN networks n ON n.id = dp.network_id
       WHERE dp.id = $1 AND dp.active = true FOR UPDATE`,
      [planId]
    );
    const plan = planResult.rows[0];
    if (!plan) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "That data plan is not available." });
    }

    const userResult = await client.query(
      "SELECT wallet_balance_kobo FROM users WHERE id = $1 FOR UPDATE",
      [req.user.id]
    );
    const balance = userResult.rows[0].wallet_balance_kobo;
    if (balance < plan.price_kobo) {
      await client.query("ROLLBACK");
      return res.status(402).json({ error: "Insufficient wallet balance. Please fund your wallet." });
    }

    // Debit first, then attempt delivery — if delivery fails we refund inside the same flow.
    await client.query(
      "UPDATE users SET wallet_balance_kobo = wallet_balance_kobo - $1 WHERE id = $2",
      [plan.price_kobo, req.user.id]
    );

    const reference = `purchase_${req.user.id}_${Date.now()}`;
    const txResult = await client.query(
      `INSERT INTO transactions (user_id, type, amount_kobo, status, plan_id, recipient_phone, reference, note)
       VALUES ($1, 'purchase', $2, 'pending', $3, $4, $5, $6)
       RETURNING id`,
      [req.user.id, plan.price_kobo, plan.id, phoneNumber, reference, `${plan.network} ${plan.name}`]
    );

    await client.query("COMMIT");

    // Delivery happens after the debit is committed, so a crash here can't double-spend.
    const delivery = await deliverData({
      networkName: plan.network,
      providerPlanCode: plan.provider_plan_code,
      phoneNumber
    });

    if (delivery.success) {
      await query("UPDATE transactions SET status = 'success', note = $1 WHERE id = $2", [
        `${plan.network} ${plan.name} delivered to ${phoneNumber}`,
        txResult.rows[0].id
      ]);
      return res.json({
        success: true,
        message: `${plan.network} ${plan.name} sent to ${phoneNumber}.`,
        reference
      });
    }

    // Delivery failed — refund the wallet and mark the transaction failed.
    await query("UPDATE users SET wallet_balance_kobo = wallet_balance_kobo + $1 WHERE id = $2", [
      plan.price_kobo,
      req.user.id
    ]);
    await query("UPDATE transactions SET status = 'failed', note = $1 WHERE id = $2", [
      `Delivery failed: ${delivery.message}. Amount refunded.`,
      txResult.rows[0].id
    ]);

    return res.status(502).json({
      success: false,
      error: "We couldn't deliver the data right now. Your wallet has been refunded."
    });
  } catch (err) {
    await client.query("ROLLBACK").catch(() => {});
    console.error("[purchase] error:", err.message);
    res.status(500).json({ error: "Purchase failed. Please try again." });
  } finally {
    client.release();
  }
});

module.exports = router;
