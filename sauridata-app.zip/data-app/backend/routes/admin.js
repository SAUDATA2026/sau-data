const express = require("express");
const { query } = require("../db");
const { requireAuth, requireAdmin } = require("../middleware/authMiddleware");

const router = express.Router();
router.use(requireAuth, requireAdmin);

// GET /api/admin/stats
router.get("/stats", async (req, res) => {
  const [users, revenue, purchases] = await Promise.all([
    query("SELECT COUNT(*)::int AS count FROM users WHERE role = 'customer'"),
    query("SELECT COALESCE(SUM(amount_kobo),0)::bigint AS total FROM transactions WHERE type = 'fund' AND status = 'success'"),
    query("SELECT COUNT(*)::int AS count FROM transactions WHERE type = 'purchase' AND status = 'success'")
  ]);
  res.json({
    totalCustomers: users.rows[0].count,
    totalFundedKobo: revenue.rows[0].total,
    totalDataSold: purchases.rows[0].count
  });
});

// GET /api/admin/users
router.get("/users", async (req, res) => {
  const result = await query(
    `SELECT id, full_name, email, phone, wallet_balance_kobo, created_at
     FROM users WHERE role = 'customer' ORDER BY created_at DESC LIMIT 200`
  );
  res.json({ users: result.rows });
});

// GET /api/admin/transactions
router.get("/transactions", async (req, res) => {
  const result = await query(
    `SELECT t.id, u.full_name, u.email, t.type, t.amount_kobo, t.status,
            t.recipient_phone, t.reference, t.note, t.created_at
     FROM transactions t JOIN users u ON u.id = t.user_id
     ORDER BY t.created_at DESC LIMIT 200`
  );
  res.json({ transactions: result.rows });
});

// GET /api/admin/plans (includes inactive, for management)
router.get("/plans", async (req, res) => {
  const result = await query(
    `SELECT dp.id, dp.name, dp.size_mb, dp.validity_days, dp.price_kobo, dp.cost_kobo,
            dp.active, n.name AS network, n.id AS network_id
     FROM data_plans dp JOIN networks n ON n.id = dp.network_id
     ORDER BY n.name, dp.price_kobo`
  );
  res.json({ plans: result.rows });
});

// POST /api/admin/plans — create a plan
router.post("/plans", async (req, res) => {
  const { networkId, name, sizeMb, validityDays, priceNaira, costNaira, providerPlanCode } = req.body || {};
  if (!networkId || !name || !sizeMb || !validityDays || !priceNaira) {
    return res.status(400).json({ error: "networkId, name, sizeMb, validityDays, and priceNaira are required." });
  }
  const result = await query(
    `INSERT INTO data_plans (network_id, name, size_mb, validity_days, price_kobo, cost_kobo, provider_plan_code, active)
     VALUES ($1,$2,$3,$4,$5,$6,$7,true) RETURNING *`,
    [networkId, name, sizeMb, validityDays, Math.round(priceNaira * 100), Math.round((costNaira || 0) * 100), providerPlanCode || null]
  );
  res.status(201).json({ plan: result.rows[0] });
});

// PATCH /api/admin/plans/:id — update price/active status
router.patch("/plans/:id", async (req, res) => {
  const { priceNaira, costNaira, active } = req.body || {};
  const fields = [];
  const values = [];
  let i = 1;

  if (priceNaira !== undefined) { fields.push(`price_kobo = $${i++}`); values.push(Math.round(priceNaira * 100)); }
  if (costNaira !== undefined) { fields.push(`cost_kobo = $${i++}`); values.push(Math.round(costNaira * 100)); }
  if (active !== undefined) { fields.push(`active = $${i++}`); values.push(active); }

  if (!fields.length) return res.status(400).json({ error: "Nothing to update." });

  values.push(req.params.id);
  const result = await query(
    `UPDATE data_plans SET ${fields.join(", ")} WHERE id = $${i} RETURNING *`,
    values
  );
  if (!result.rows.length) return res.status(404).json({ error: "Plan not found." });
  res.json({ plan: result.rows[0] });
});

// POST /api/admin/wallet-adjustment — manual credit/debit (e.g. refunds, goodwill credit)
router.post("/wallet-adjustment", async (req, res) => {
  const { userId, amountNaira, note } = req.body || {};
  if (!userId || !amountNaira) {
    return res.status(400).json({ error: "userId and amountNaira are required." });
  }
  const amountKobo = Math.round(amountNaira * 100); // can be negative to debit

  await query("UPDATE users SET wallet_balance_kobo = wallet_balance_kobo + $1 WHERE id = $2", [amountKobo, userId]);
  await query(
    `INSERT INTO transactions (user_id, type, amount_kobo, status, note)
     VALUES ($1, 'admin_adjustment', $2, 'success', $3)`,
    [userId, amountKobo, note || "Manual adjustment by admin"]
  );
  res.json({ success: true });
});

module.exports = router;
