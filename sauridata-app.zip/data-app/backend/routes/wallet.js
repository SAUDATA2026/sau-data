const express = require("express");
const crypto = require("crypto");
const { query } = require("../db");
const { requireAuth } = require("../middleware/authMiddleware");
const paystack = require("../services/paystack");

const router = express.Router();

// GET /api/wallet/balance
router.get("/balance", requireAuth, async (req, res) => {
  const result = await query("SELECT wallet_balance_kobo FROM users WHERE id = $1", [req.user.id]);
  res.json({ balanceKobo: result.rows[0]?.wallet_balance_kobo ?? 0 });
});

// GET /api/wallet/transactions
router.get("/transactions", requireAuth, async (req, res) => {
  const result = await query(
    `SELECT id, type, amount_kobo, status, plan_id, recipient_phone, reference, note, created_at
     FROM transactions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50`,
    [req.user.id]
  );
  res.json({ transactions: result.rows });
});

// POST /api/wallet/fund  { amountNaira }
router.post("/fund", requireAuth, async (req, res) => {
  const { amountNaira } = req.body || {};
  const amount = Number(amountNaira);
  if (!amount || amount < 50) {
    return res.status(400).json({ error: "Enter a valid amount (minimum ₦50)." });
  }

  const amountKobo = Math.round(amount * 100);
  const reference = `fund_${req.user.id}_${Date.now()}`;

  try {
    await query(
      `INSERT INTO wallet_fundings (user_id, amount_kobo, paystack_reference, status)
       VALUES ($1, $2, $3, 'pending')`,
      [req.user.id, amountKobo, reference]
    );

    const paystackData = await paystack.initializeTransaction({
      email: req.user.email,
      amountKobo,
      reference
    });

    res.json({ authorizationUrl: paystackData.authorization_url, reference });
  } catch (err) {
    console.error("[wallet] fund init error:", err.message);
    res.status(502).json({ error: "Could not start payment. Please try again." });
  }
});

// GET /api/wallet/verify/:reference — used by the callback page as a friendly fallback;
// the webhook below is the source of truth for actually crediting the wallet.
router.get("/verify/:reference", requireAuth, async (req, res) => {
  const { reference } = req.params;
  const result = await query("SELECT status, amount_kobo FROM wallet_fundings WHERE paystack_reference = $1 AND user_id = $2", [reference, req.user.id]);
  if (!result.rows.length) return res.status(404).json({ error: "Funding record not found." });
  res.json(result.rows[0]);
});

// POST /webhooks/paystack — mounted separately in server.js with raw body parsing
async function paystackWebhookHandler(req, res) {
  const signature = req.headers["x-paystack-signature"];
  const valid = paystack.verifyWebhookSignature(req.rawBody, signature);
  if (!valid) return res.sendStatus(401);

  res.sendStatus(200); // ack fast

  try {
    const event = JSON.parse(req.rawBody);
    if (event.event !== "charge.success") return;

    const reference = event.data.reference;
    const funding = await query(
      "SELECT * FROM wallet_fundings WHERE paystack_reference = $1",
      [reference]
    );
    const record = funding.rows[0];
    if (!record || record.status === "success") return; // already processed or unknown

    // Confirm directly with Paystack before crediting, defense in depth.
    const verified = await paystack.verifyTransaction(reference);
    if (verified.status !== "success") return;

    await query("BEGIN");
    await query(
      "UPDATE wallet_fundings SET status = 'success' WHERE paystack_reference = $1",
      [reference]
    );
    await query(
      "UPDATE users SET wallet_balance_kobo = wallet_balance_kobo + $1 WHERE id = $2",
      [record.amount_kobo, record.user_id]
    );
    await query(
      `INSERT INTO transactions (user_id, type, amount_kobo, status, reference, note)
       VALUES ($1, 'fund', $2, 'success', $3, 'Wallet funded via Paystack')`,
      [record.user_id, record.amount_kobo, reference]
    );
    await query("COMMIT");
  } catch (err) {
    await query("ROLLBACK").catch(() => {});
    console.error("[wallet] webhook processing error:", err.message);
  }
}

module.exports = { router, paystackWebhookHandler };
