require("dotenv").config();
const express = require("express");
const cors = require("cors");
const rateLimit = require("express-rate-limit");

const authRoutes = require("./routes/auth");
const { router: walletRoutes, paystackWebhookHandler } = require("./routes/wallet");
const plansRoutes = require("./routes/plans");
const purchaseRoutes = require("./routes/purchase");
const adminRoutes = require("./routes/admin");

const app = express();

app.use(cors({ origin: process.env.CORS_ORIGIN || "*" }));

// Paystack webhook needs the raw body to verify the HMAC signature, so it's
// registered BEFORE the JSON body parser and captures rawBody manually.
app.post(
  "/webhooks/paystack",
  express.raw({ type: "application/json" }),
  (req, res, next) => {
    req.rawBody = req.body.toString("utf8");
    next();
  },
  paystackWebhookHandler
);

app.use(express.json());

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 30 });
const purchaseLimiter = rateLimit({ windowMs: 60 * 1000, max: 10 });

app.get("/health", (req, res) => res.json({ status: "ok" }));

app.use("/api/auth", authLimiter, authRoutes);
app.use("/api/wallet", walletRoutes);
app.use("/api/plans", plansRoutes);
app.use("/api/purchase", purchaseLimiter, purchaseRoutes);
app.use("/api/admin", adminRoutes);

app.use((req, res) => res.status(404).json({ error: "Not found." }));

app.use((err, req, res, next) => {
  console.error("[server] unhandled error:", err);
  res.status(500).json({ error: "Something went wrong. Please try again." });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`SauriData backend listening on port ${PORT}`);
});
