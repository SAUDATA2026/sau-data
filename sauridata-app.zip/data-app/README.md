# SauriData — Data Vending App (Customer App + Admin Dashboard)
*"Saye da Sayar da Data Cikin Sauki" — Buy and manage mobile data, simply.*

A complete reference build for an app that sells mobile data bundles (like a digital
recharge-card business) for MTN, Glo, Airtel, and 9mobile — with a customer-facing wallet
app and an admin dashboard, wired to **Paystack** for funding.

---

## 1. What this app does

- Customers register, fund an in-app **wallet** via Paystack, then buy data plans for any
  supported network — the data is delivered to any phone number they enter (their own or a
  gift purchase for someone else), just like buying a recharge card.
- Every purchase debits the wallet instantly; there's no repeated card entry.
- Admins manage the list of data plans and prices, watch transactions in real time, view
  customers, and manually adjust wallets (e.g. for refunds).
- The customer app is an **installable PWA** (Progressive Web App) with its own **product
  landing/download page** — people can "download" it straight from their phone's browser,
  no app store required. See section 8 below.

---

## 2. Architecture

```
                 ┌─────────────────────┐        ┌─────────────────────┐
                 │   Customer App       │        │   Admin Dashboard    │
                 │ (frontend/customer)  │        │ (frontend/admin)     │
                 └──────────┬───────────┘        └──────────┬───────────┘
                            │  REST (JWT)                    │ REST (JWT, role=admin)
                            ▼                                 ▼
                 ┌─────────────────────────────────────────────────┐
                 │                Express API (backend)              │
                 │  routes: auth, wallet, plans, purchase, admin     │
                 │  middleware: JWT auth, role check                 │
                 └───────────┬───────────────────┬──────────────────┘
                             │                    │
                 ┌───────────▼──────────┐  ┌──────▼────────────────┐
                 │   PostgreSQL          │  │  External services     │
                 │  users, plans,        │  │  - Paystack (funding)  │
                 │  transactions,        │  │  - VTU provider        │
                 │  wallet_fundings      │  │    (data delivery)     │
                 └────────────────────────┘  └────────────────────────┘
```

**Money flow (important):** customers never pay Paystack *per purchase*. They fund a wallet
via Paystack (that's the only place real money touches a card/bank), and every data
purchase is an internal wallet debit. This is faster for the customer and is how virtually
every data-reselling app works — it also means a failed data delivery is a simple wallet
refund, not a payment-gateway reversal.

**VTU provider adapter:** actually delivering data onto a phone number requires a
"VTU" (Virtual Top-Up) provider — e.g. VTpass, Clubkonnect, or a direct telco API. Because
every provider has a different API, `backend/services/vtu.js` is a single swappable
adapter: it currently ships with a **mock implementation** (always succeeds, for
development/demo) and clearly marked spots to drop in real provider credentials/calls.
Nothing else in the app needs to change when you plug in a real provider.

---

## 3. Database schema

See `backend/db/schema.sql`. Summary:

| Table | Purpose |
|---|---|
| `users` | customers + admins, `role` column, `wallet_balance_kobo` |
| `networks` | MTN / Glo / Airtel / 9mobile |
| `data_plans` | plan name, size, validity, price, network, active flag |
| `transactions` | every wallet-affecting event: `fund` or `purchase`, amount, status |
| `wallet_fundings` | Paystack references tied to wallet top-ups, for reconciliation |

All money is stored in **kobo (smallest currency unit)** as integers to avoid float
rounding errors — display code divides by 100 for Naira.

---

## 4. Paystack integration flow

1. Customer taps "Fund Wallet", enters an amount.
2. Backend calls `POST https://api.paystack.co/transaction/initialize` with the amount and
   the customer's email, gets back an `authorization_url`.
3. Frontend redirects the customer to that URL (Paystack's hosted checkout).
4. On success, Paystack redirects back to your `callback_url` **and** sends a webhook to
   `POST /webhooks/paystack` — the backend trusts the **webhook** (verified via HMAC
   signature) to actually credit the wallet, not the redirect, since redirects can be
   spoofed or interrupted.
5. Backend verifies the transaction with `GET /transaction/verify/:reference`, and only
   then credits `wallet_balance_kobo` and marks the `wallet_fundings` row as `success`.

```javascript
// Initialize (backend/services/paystack.js)
const res = await fetch("https://api.paystack.co/transaction/initialize", {
  method: "POST",
  headers: {
    Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
    "Content-Type": "application/json"
  },
  body: JSON.stringify({ email, amount: amountKobo, callback_url })
});
```

```javascript
// Webhook signature verification
const crypto = require("crypto");
const hash = crypto
  .createHmac("sha512", process.env.PAYSTACK_SECRET_KEY)
  .update(rawBody)
  .digest("hex");
if (hash !== req.headers["x-paystack-signature"]) return res.sendStatus(401);
```

---

## 5. Installable app + download page ("sell it like an app")

People can "download" SauriData straight from their phone's browser — no Play Store or App
Store submission needed. This is done with a **PWA (Progressive Web App)**:

- `frontend/customer/manifest.json` — declares the app's name, icons, and colors so the
  browser knows how to install it (icon, splash screen, standalone window with no browser
  address bar).
- `frontend/customer/service-worker.js` — caches the app shell so it opens instantly and
  qualifies as installable (this is a browser requirement, not optional decoration).
- `frontend/customer/icons/` — generated app icons (192px, 512px, a maskable 512px for
  Android's adaptive-icon shapes, and an Apple touch icon).
- Install prompt logic lives in `app.js`: on Android/Chrome it listens for the browser's
  native `beforeinstallprompt` event and shows a bottom banner with an **Install** button;
  on iOS (which has no install-prompt API) it shows the same banner but taps open a short
  "Add to Home Screen" instruction modal, since that's the only install path Safari offers.

**`frontend/landing/`** is a separate marketing/download page — the "storefront" — styled
like a product you'd find in an app store: hero section with a phone mockup of the app,
a stats strip, feature grid, a 3-step "how it works," and a closing call-to-action. Its
**Get SauriData** buttons link straight into `frontend/customer/index.html`, where the
actual install banner takes over. Point your domain's root at `landing/index.html` and
your app at a path like `/app/` (i.e. deploy `frontend/customer/` there).

**To test the install flow locally:** installability requires HTTPS (or `localhost`), so
serve the customer folder rather than opening the HTML file directly:
```bash
cd frontend/customer
npx serve .        # or any static server
```
Open it in Chrome on Android or desktop and you'll see the install banner; on an iPhone,
open it in Safari (not Chrome — iOS install only works from Safari).

---

## 6. Setup

```bash
cd backend
cp .env.example .env          # fill in Paystack keys, DB URL, JWT secret
psql "$DATABASE_URL" -f db/schema.sql
npm install
npm run dev                    # http://localhost:4000
```

Open `frontend/customer/index.html` for the customer app and
`frontend/admin/index.html` for the admin dashboard (both talk to the API via
`API_BASE` set at the top of each `app.js`).

**Default admin account:** create one manually after signup by running:
```sql
UPDATE users SET role = 'admin' WHERE email = 'you@example.com';
```

---

## 7. Deployment

- **API**: same pattern as any Node/Express app — Render/Railway/Fly.io/VPS behind Nginx,
  containerized with the included `Dockerfile`.
- **Database**: managed Postgres (Supabase, Neon, RDS, Railway Postgres).
- **Webhooks**: Paystack requires **HTTPS**, so the `/webhooks/paystack` endpoint must be
  publicly reachable over TLS — set the webhook URL in your Paystack dashboard under
  Settings → API Keys & Webhooks.
- **Frontends**: static hosting (Netlify/Vercel/S3) for the landing page, customer app, and
  admin app, or serve them from the same Express app via `express.static`. Because the
  customer app is a PWA, make sure it's served over HTTPS in production (any of the hosts
  above do this by default) or the install prompt won't appear.

---

## 8. Project structure

```
data-app/
├── README.md
├── backend/
│   ├── server.js
│   ├── package.json
│   ├── .env.example
│   ├── Dockerfile
│   ├── db/schema.sql
│   ├── middleware/authMiddleware.js
│   ├── services/
│   │   ├── paystack.js
│   │   └── vtu.js
│   └── routes/
│       ├── auth.js
│       ├── wallet.js
│       ├── plans.js
│       ├── purchase.js
│       └── admin.js
└── frontend/
    ├── landing/  (index.html, style.css) — product/download page
    ├── customer/ (index.html, style.css, app.js, manifest.json,
    │              service-worker.js, icons/) — installable PWA
    └── admin/    (index.html, style.css, app.js)
```
