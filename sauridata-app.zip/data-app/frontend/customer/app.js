const API_BASE = window.SAURIDATA_API_BASE || "http://localhost:4000/api";

let token = localStorage.getItem("sd_token");
let currentUser = JSON.parse(localStorage.getItem("sd_user") || "null");
let plansByNetwork = {};
let activeNetwork = null;
let selectedPlan = null;

// ---------- helpers ----------
function naira(kobo) {
  return "₦" + (kobo / 100).toLocaleString("en-NG", { minimumFractionDigits: 2 });
}

function showToast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.remove("hidden");
  setTimeout(() => t.classList.add("hidden"), 3200);
}

async function api(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {})
    }
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}

// ---------- auth ----------
document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById("login-form").classList.toggle("hidden", tab.dataset.tab !== "login");
    document.getElementById("signup-form").classList.toggle("hidden", tab.dataset.tab !== "signup");
  });
});

document.getElementById("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const errorEl = document.getElementById("login-error");
  errorEl.textContent = "";
  try {
    const data = await api("/auth/login", {
      method: "POST",
      body: JSON.stringify({
        email: document.getElementById("login-email").value.trim(),
        password: document.getElementById("login-password").value
      })
    });
    onAuthSuccess(data);
  } catch (err) {
    errorEl.textContent = err.message;
  }
});

document.getElementById("signup-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const errorEl = document.getElementById("signup-error");
  errorEl.textContent = "";
  try {
    const data = await api("/auth/signup", {
      method: "POST",
      body: JSON.stringify({
        fullName: document.getElementById("signup-name").value.trim(),
        email: document.getElementById("signup-email").value.trim(),
        phone: document.getElementById("signup-phone").value.trim(),
        password: document.getElementById("signup-password").value
      })
    });
    onAuthSuccess(data);
  } catch (err) {
    errorEl.textContent = err.message;
  }
});

function onAuthSuccess(data) {
  token = data.token;
  currentUser = data.user;
  localStorage.setItem("sd_token", token);
  localStorage.setItem("sd_user", JSON.stringify(currentUser));
  showApp();
}

document.getElementById("logout-btn").addEventListener("click", () => {
  token = null;
  currentUser = null;
  localStorage.removeItem("sd_token");
  localStorage.removeItem("sd_user");
  document.getElementById("app-screen").classList.add("hidden");
  document.getElementById("auth-screen").classList.remove("hidden");
});

// ---------- section switching ----------
document.querySelectorAll(".section-tab").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".section-tab").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById("buy-section").classList.toggle("hidden", btn.dataset.section !== "buy");
    document.getElementById("history-section").classList.toggle("hidden", btn.dataset.section !== "history");
    if (btn.dataset.section === "history") loadTransactions();
  });
});

// ---------- app bootstrap ----------
async function showApp() {
  document.getElementById("auth-screen").classList.add("hidden");
  document.getElementById("app-screen").classList.remove("hidden");
  await Promise.all([loadBalance(), loadPlans()]);
}

async function loadBalance() {
  try {
    const data = await api("/wallet/balance");
    document.getElementById("wallet-balance").textContent = naira(data.balanceKobo);
  } catch (err) {
    showToast(err.message);
  }
}

async function loadPlans() {
  try {
    const data = await api("/plans");
    plansByNetwork = data.plans;
    const networks = Object.keys(plansByNetwork);
    activeNetwork = networks[0] || null;
    renderNetworkTabs(networks);
    renderPlans();
  } catch (err) {
    document.getElementById("plans-grid").innerHTML = `<p class="empty-state">${err.message}</p>`;
  }
}

function renderNetworkTabs(networks) {
  const el = document.getElementById("network-tabs");
  el.innerHTML = networks
    .map((n) => `<button class="network-chip ${n === activeNetwork ? "active" : ""}" data-network="${n}">${n}</button>`)
    .join("");
  el.querySelectorAll(".network-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      activeNetwork = chip.dataset.network;
      el.querySelectorAll(".network-chip").forEach((c) => c.classList.remove("active"));
      chip.classList.add("active");
      renderPlans();
    });
  });
}

function renderPlans() {
  const grid = document.getElementById("plans-grid");
  const plans = plansByNetwork[activeNetwork] || [];
  if (!plans.length) {
    grid.innerHTML = `<p class="empty-state">No plans available right now.</p>`;
    return;
  }
  grid.innerHTML = plans
    .map(
      (p) => `
      <div class="plan-card" data-id="${p.id}">
        <div class="plan-size">${(p.size_mb / 1000).toFixed(p.size_mb % 1000 === 0 ? 0 : 1)}GB</div>
        <div class="plan-validity">${p.validity_days} days</div>
        <div class="plan-price">${naira(p.price_kobo)}</div>
      </div>`
    )
    .join("");

  grid.querySelectorAll(".plan-card").forEach((card) => {
    card.addEventListener("click", () => {
      selectedPlan = plans.find((p) => String(p.id) === card.dataset.id);
      openBuyModal();
    });
  });
}

async function loadTransactions() {
  const list = document.getElementById("tx-list");
  try {
    const data = await api("/wallet/transactions");
    if (!data.transactions.length) {
      list.innerHTML = `<p class="empty-state">No transactions yet.</p>`;
      return;
    }
    list.innerHTML = data.transactions
      .map((t) => {
        const isCredit = t.type === "fund" || (t.type === "admin_adjustment" && t.amount_kobo > 0) || t.type === "refund";
        return `
        <div class="tx-item">
          <div>
            <div class="tx-main">${t.note || t.type}</div>
            <div class="tx-date">${new Date(t.created_at).toLocaleString()}</div>
          </div>
          <div style="text-align:right">
            <div class="tx-amount ${isCredit ? "positive" : "negative"}">${isCredit ? "+" : "-"}${naira(Math.abs(t.amount_kobo))}</div>
            <span class="tx-status ${t.status}">${t.status}</span>
          </div>
        </div>`;
      })
      .join("");
  } catch (err) {
    list.innerHTML = `<p class="empty-state">${err.message}</p>`;
  }
}

// ---------- fund wallet ----------
document.getElementById("fund-btn").addEventListener("click", () => {
  document.getElementById("fund-error").textContent = "";
  document.getElementById("fund-amount").value = "";
  document.getElementById("fund-modal").classList.remove("hidden");
});
document.getElementById("fund-cancel").addEventListener("click", () => {
  document.getElementById("fund-modal").classList.add("hidden");
});
document.getElementById("fund-confirm").addEventListener("click", async () => {
  const errorEl = document.getElementById("fund-error");
  const amount = Number(document.getElementById("fund-amount").value);
  if (!amount || amount < 50) {
    errorEl.textContent = "Enter a valid amount (minimum ₦50).";
    return;
  }
  try {
    const data = await api("/wallet/fund", { method: "POST", body: JSON.stringify({ amountNaira: amount }) });
    window.location.href = data.authorizationUrl; // redirect to Paystack checkout
  } catch (err) {
    errorEl.textContent = err.message;
  }
});

// ---------- buy data ----------
function openBuyModal() {
  document.getElementById("buy-error").textContent = "";
  document.getElementById("buy-phone").value = "";
  document.getElementById("buy-modal-plan").textContent =
    `${activeNetwork} — ${(selectedPlan.size_mb / 1000).toFixed(selectedPlan.size_mb % 1000 === 0 ? 0 : 1)}GB / ${selectedPlan.validity_days} days — ${naira(selectedPlan.price_kobo)}`;
  document.getElementById("buy-modal").classList.remove("hidden");
}
document.getElementById("buy-cancel").addEventListener("click", () => {
  document.getElementById("buy-modal").classList.add("hidden");
});
document.getElementById("buy-confirm").addEventListener("click", async () => {
  const errorEl = document.getElementById("buy-error");
  const phone = document.getElementById("buy-phone").value.trim();
  if (!/^0\d{10}$/.test(phone)) {
    errorEl.textContent = "Enter a valid 11-digit phone number (e.g. 08012345678).";
    return;
  }
  try {
    const data = await api("/purchase", {
      method: "POST",
      body: JSON.stringify({ planId: selectedPlan.id, phoneNumber: phone })
    });
    document.getElementById("buy-modal").classList.add("hidden");
    showToast(data.message);
    loadBalance();
  } catch (err) {
    errorEl.textContent = err.message;
  }
});

// ---------- installable app (PWA) ----------
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("service-worker.js").catch(() => {});
  });
}

let deferredInstallPrompt = null;
const installBanner = document.getElementById("install-banner");
const installBtn = document.getElementById("install-btn");
const installDismiss = document.getElementById("install-dismiss");

function isStandalone() {
  return window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
}
function isIOS() {
  return /iphone|ipad|ipod/i.test(window.navigator.userAgent);
}

if (!isStandalone() && !localStorage.getItem("sd_install_dismissed")) {
  if (isIOS()) {
    // iOS has no install prompt event — show the banner immediately, tapping it opens instructions.
    installBanner.classList.remove("hidden");
  } else {
    window.addEventListener("beforeinstallprompt", (e) => {
      e.preventDefault();
      deferredInstallPrompt = e;
      installBanner.classList.remove("hidden");
    });
  }
}

installBtn.addEventListener("click", async () => {
  if (isIOS()) {
    document.getElementById("ios-install-modal").classList.remove("hidden");
    return;
  }
  if (!deferredInstallPrompt) return;
  deferredInstallPrompt.prompt();
  await deferredInstallPrompt.userChoice;
  deferredInstallPrompt = null;
  installBanner.classList.add("hidden");
});

installDismiss.addEventListener("click", () => {
  installBanner.classList.add("hidden");
  localStorage.setItem("sd_install_dismissed", "1");
});

document.getElementById("ios-install-close").addEventListener("click", () => {
  document.getElementById("ios-install-modal").classList.add("hidden");
});

window.addEventListener("appinstalled", () => {
  installBanner.classList.add("hidden");
});

// ---------- init ----------
if (token && currentUser) {
  showApp();
}
