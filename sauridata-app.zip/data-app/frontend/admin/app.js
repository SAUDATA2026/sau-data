const API_BASE = window.SAURIDATA_API_BASE || "http://localhost:4000/api";

let token = localStorage.getItem("sd_admin_token");

function naira(kobo) {
  return "₦" + (kobo / 100).toLocaleString("en-NG", { minimumFractionDigits: 2 });
}

function showToast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.remove("hidden");
  setTimeout(() => t.classList.add("hidden"), 3200);
}

async function api(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {})
    }
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}

// ---------- auth ----------
document.getElementById("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const errorEl = document.getElementById("login-error");
  errorEl.textContent = "";
  try {
    const data = await api("/auth/login", {
      method: "POST",
      body: JSON.stringify({
        email: document.getElementById("login-email").value.trim(),
        password: document.getElementById("login-password").value
      })
    });
    if (data.user.role !== "admin") {
      errorEl.textContent = "This account does not have admin access.";
      return;
    }
    token = data.token;
    localStorage.setItem("sd_admin_token", token);
    showApp();
  } catch (err) {
    errorEl.textContent = err.message;
  }
});

document.getElementById("logout-btn").addEventListener("click", () => {
  token = null;
  localStorage.removeItem("sd_admin_token");
  document.getElementById("app-screen").classList.add("hidden");
  document.getElementById("auth-screen").classList.remove("hidden");
});

// ---------- nav ----------
document.querySelectorAll(".nav-item").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    document.querySelectorAll(".view").forEach((v) => v.classList.add("hidden"));
    document.getElementById(`view-${btn.dataset.view}`).classList.remove("hidden");
    loadView(btn.dataset.view);
  });
});

async function showApp() {
  document.getElementById("auth-screen").classList.add("hidden");
  document.getElementById("app-screen").classList.remove("hidden");
  loadView("overview");
}

function loadView(view) {
  if (view === "overview") loadOverview();
  if (view === "plans") loadPlans();
  if (view === "users") loadUsers();
  if (view === "transactions") loadTransactions();
}

async function loadOverview() {
  try {
    const data = await api("/admin/stats");
    document.getElementById("stat-customers").textContent = data.totalCustomers;
    document.getElementById("stat-funding").textContent = naira(data.totalFundedKobo);
    document.getElementById("stat-sold").textContent = data.totalDataSold;
  } catch (err) {
    showToast(err.message);
  }
}

async function loadPlans() {
  const tbody = document.getElementById("plans-tbody");
  try {
    const data = await api("/admin/plans");
    tbody.innerHTML = data.plans
      .map(
        (p) => `
        <tr>
          <td>${p.network}</td>
          <td>${p.name}</td>
          <td>${naira(p.price_kobo)}</td>
          <td>${naira(p.cost_kobo)}</td>
          <td><span class="status-pill ${p.active ? "active" : "inactive"}">${p.active ? "Active" : "Inactive"}</span></td>
          <td><button class="toggle-link" data-id="${p.id}" data-active="${p.active}">${p.active ? "Deactivate" : "Activate"}</button></td>
        </tr>`
      )
      .join("");

    tbody.querySelectorAll(".toggle-link").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          await api(`/admin/plans/${btn.dataset.id}`, {
            method: "PATCH",
            body: JSON.stringify({ active: btn.dataset.active !== "true" })
          });
          loadPlans();
        } catch (err) {
          showToast(err.message);
        }
      });
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6">${err.message}</td></tr>`;
  }
}

async function loadUsers() {
  const tbody = document.getElementById("users-tbody");
  try {
    const data = await api("/admin/users");
    tbody.innerHTML = data.users
      .map(
        (u) => `
        <tr>
          <td>${u.full_name}</td>
          <td>${u.email}</td>
          <td>${u.phone}</td>
          <td>${naira(u.wallet_balance_kobo)}</td>
          <td>${new Date(u.created_at).toLocaleDateString()}</td>
        </tr>`
      )
      .join("");
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="5">${err.message}</td></tr>`;
  }
}

async function loadTransactions() {
  const tbody = document.getElementById("tx-tbody");
  try {
    const data = await api("/admin/transactions");
    tbody.innerHTML = data.transactions
      .map(
        (t) => `
        <tr>
          <td>${t.full_name}<br><span style="color:var(--sage);font-size:0.78rem">${t.email}</span></td>
          <td>${t.type}</td>
          <td>${naira(t.amount_kobo)}</td>
          <td><span class="status-pill ${t.status}">${t.status}</span></td>
          <td>${t.note || "—"}</td>
          <td>${new Date(t.created_at).toLocaleString()}</td>
        </tr>`
      )
      .join("");
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6">${err.message}</td></tr>`;
  }
}

// ---------- add plan modal ----------
document.getElementById("add-plan-btn").addEventListener("click", () => {
  document.getElementById("plan-error").textContent = "";
  document.getElementById("plan-modal").classList.remove("hidden");
});
document.getElementById("plan-cancel").addEventListener("click", () => {
  document.getElementById("plan-modal").classList.add("hidden");
});
document.getElementById("plan-save").addEventListener("click", async () => {
  const errorEl = document.getElementById("plan-error");
  const payload = {
    networkId: Number(document.getElementById("plan-network").value),
    name: document.getElementById("plan-name").value.trim(),
    sizeMb: Number(document.getElementById("plan-size").value),
    validityDays: Number(document.getElementById("plan-validity").value),
    priceNaira: Number(document.getElementById("plan-price").value),
    costNaira: Number(document.getElementById("plan-cost").value)
  };
  if (!payload.name || !payload.sizeMb || !payload.validityDays || !payload.priceNaira) {
    errorEl.textContent = "Please fill in all fields.";
    return;
  }
  try {
    await api("/admin/plans", { method: "POST", body: JSON.stringify(payload) });
    document.getElementById("plan-modal").classList.add("hidden");
    showToast("Plan added.");
    loadPlans();
  } catch (err) {
    errorEl.textContent = err.message;
  }
});

// ---------- init ----------
if (token) showApp();
